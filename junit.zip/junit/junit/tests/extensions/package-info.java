/**
 * Tests for the JUnit v3.x extension functionality.
 */
package junit.tests.extensions;