/*
 * This code is sample code, provided as-is, and we make no
 * warranties as to its correctness or suitability for
 * any purpose.
 *
 * We hope that it's useful to you.  Enjoy.
 * Copyright LearningPatterns Inc.
 */
package com.javatunes.catalog;

import static java.util.stream.Collectors.*;
import static org.junit.Assert.*;
import java.time.DayOfWeek;
import java.time.Month;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import org.junit.Before;
import org.junit.Test;

public class MusicItemDateTest {
  
  private Collection<MusicItem> allMusicItems;

  @Before
  public void setUp() {
    Catalog catalog = new InMemoryCatalog();
    allMusicItems = catalog.getAll();
  }
  
  /**
   * OPTIONAL: how many items were released on a Friday?
   * Just use visual inspection (sysout), we don't expect you to look up all those dates on the calendar!
   * 
   * RESULT: 3
   */
  @Test
  public void testReleaseDay() {
    // DONE
    long count = allMusicItems.stream()
      .filter(item -> item.getReleaseDate().toLocalDate().getDayOfWeek() == DayOfWeek.FRIDAY)
      .count();
    System.out.println(count);
  }

  /**
   * OPTIONAL: group MusicItems by month released.
   * 
   * RESULT:
   *  JANUARY   List<MusicItem>[1,5,8]
   *  FEBRUARY  List<MusicItem>[2,13,18]
   *  MAY       List<MusicItem>[15]
   *  JUNE      List<MusicItem>[10]
   *  AUGUST    List<MusicItem>[3,4,6,17]
   *  OCTOBER   List<MusicItem>[12,14,16]
   *  DECEMBER  List<MusicItem>[7,9,11]
   */
  @Test
  public void testGroupByMonth() {
    // DONE
    Map<Month,List<MusicItem>> itemMap = allMusicItems.stream()
      .collect(groupingBy(item -> item.getReleaseDate().toLocalDate().getMonth()));
    
    assertEquals(7, itemMap.size());
    assertEquals(3, itemMap.get(Month.JANUARY).size());
    assertEquals(3, itemMap.get(Month.FEBRUARY).size());
    assertNull(itemMap.get(Month.MARCH));
    assertNull(itemMap.get(Month.APRIL));
    assertEquals(1, itemMap.get(Month.MAY).size());
    assertEquals(1, itemMap.get(Month.JUNE).size());
    assertNull(itemMap.get(Month.JULY));
    assertEquals(4, itemMap.get(Month.AUGUST).size());
    assertNull(itemMap.get(Month.SEPTEMBER));
    assertEquals(3, itemMap.get(Month.OCTOBER).size());
    assertNull(itemMap.get(Month.NOVEMBER));
    assertEquals(3, itemMap.get(Month.DECEMBER).size());
  }
}