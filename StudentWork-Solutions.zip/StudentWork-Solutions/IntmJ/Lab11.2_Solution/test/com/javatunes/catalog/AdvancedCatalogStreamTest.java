/*
 * This code is sample code, provided as-is, and we make no
 * warranties as to its correctness or suitability for
 * any purpose.
 *
 * We hope that it's useful to you.  Enjoy.
 * Copyright LearningPatterns Inc.
 */
package com.javatunes.catalog;

import static java.util.Comparator.*;
import static java.util.stream.Collectors.*;
import static org.junit.Assert.*;
import java.util.Collection;
import java.util.List;
import java.util.OptionalDouble;
import org.junit.Before;
import org.junit.Test;

public class AdvancedCatalogStreamTest {
  
  private Collection<MusicItem> allMusicItems;

  @Before
  public void setUp() {
    Catalog catalog = new InMemoryCatalog();
    allMusicItems = catalog.getAll();
  }
  
  /**
   * TASK: determine average price of our low-cost, extensive catalog of music.
   * 
   * RESULT: 15.309 (via calculator)
   */
  @Test
  public void testAveragePrice() {
    OptionalDouble avgPriceOptional = allMusicItems.stream()
      .mapToDouble(MusicItem::getPrice)  // item -> item.getPrice()
      .average();
    double avgPrice = avgPriceOptional.getAsDouble();
    
    assertEquals(15.309, avgPrice, .001);
  }
  
  /**
   * TASK: determine the titles of all "pop" items, sorted by natural order.
   * 
   * RESULT: "Diva", "Dream of the Blue Turtles", "Seal", "So"
   */
  @Test
  public void testTitlesPopSortNaturalOrder() {
    // DONE
    List<String> titles = allMusicItems.stream()
      .filter(item -> item.getMusicCategory() == MusicCategory.POP)
      .map(MusicItem::getTitle)  // Stream<String>
      .sorted()
      .collect(toList());
    
    assertEquals(4, titles.size());
    assertEquals("Diva", titles.get(0));
    assertEquals("Dream of the Blue Turtles", titles.get(1));
    assertEquals("Seal", titles.get(2));
    assertEquals("So", titles.get(3));
  }
  
  /**
   * TASK: are all items priced at least $10?
   * 
   * RESULT: false
   */
  @Test
  public void testAllPriceGreaterThanEqual() {
    // DONE
    boolean allAtLeast10Dollars = allMusicItems.stream()
      .allMatch(item -> item.getPrice() >= 10.0);
    
    assertFalse(allAtLeast10Dollars);
  }
  
  /**
   * TASK: do we sell any "jazz" items?
   * 
   * RESULT: false
   */
  @Test
  public void testAnyMusicCategory() {
    // DONE
    boolean jazz = allMusicItems.stream()
      .anyMatch(item -> item.getMusicCategory() == MusicCategory.JAZZ);
    
    assertFalse(jazz);
  }
  
  /**
   * TASK: how many "blues" items do we sell?
   * 
   * RESULT: 2
   */
  @Test
  public void testCountMusicCategory() {
    // DONE
    long bluesItems = allMusicItems.stream()
      .filter(item -> item.getMusicCategory() == MusicCategory.BLUES)
      .count();
    
    assertEquals(2, bluesItems);
  }
  
  /**
   * TASK: print to stdout any 3 "rock" items.
   * 
   * RESULT: non-deterministic, but likely to be MusicItems 8, 10, 12 (encounter order)
   */
  @Test
  public void testPrintAny3MusicCategory() {
    // DONE
    allMusicItems.stream()
      .filter(item -> item.getMusicCategory() == MusicCategory.ROCK)
      .limit(3)
      .forEach(System.out::println);  // method ref: item -> System.out.println(item)
  }
  
  /**
   * TASK: determine the average price of the 3 most recent items we sell.
   * Hint: If you sort by release date, you'll get oldest items first.
   * 
   * RESULT: 17.97 (via calculator - MusicItems 9, 11, 12)
   */
  @Test
  public void testAvgPrice3Newest() {
    // DONE
    double price = allMusicItems.stream()
      .sorted(comparing(MusicItem::getReleaseDate).reversed())
      .limit(3)
      .mapToDouble(MusicItem::getPrice)  // DoubleStream
      .average()       // OptionalDouble
      .getAsDouble();  // extracted value
    
    assertEquals(17.97, price, .001);
  }
  
  /**
   * TASK: determine the 2 highest-priced MusicItems, sorted by title.
   * HINT: you will need to sort twice in the pipeline.
   * 
   * RESULT: MusicItems 15, 12
   */
  @Test
  public void testPrice2HighestSortTitle() {
    // DONE
    List<MusicItem> items = allMusicItems.stream()
      .sorted(comparing(MusicItem::getPrice).reversed())
      .limit(2)
      .sorted(comparing(MusicItem::getTitle))
      .collect(toList());
    
    assertEquals(2, items.size());
    assertEquals(Long.valueOf(15), items.get(0).getId());
    assertEquals(Long.valueOf(12), items.get(1).getId());
  }
  
  /**
   * TASK: what is the price of our cheapest "pop" item?
   * 
   * RESULT: 13.99
   */
  @Test
  public void testMinPriceMusicCategory() {
    // DONE
    double price = allMusicItems.stream()
      .filter(item -> item.getMusicCategory() == MusicCategory.POP)
      .mapToDouble(MusicItem::getPrice)
      .min()           // OptionalDouble
      .getAsDouble();  // extracted value
    
    assertEquals(13.99, price, .001);
  }
}