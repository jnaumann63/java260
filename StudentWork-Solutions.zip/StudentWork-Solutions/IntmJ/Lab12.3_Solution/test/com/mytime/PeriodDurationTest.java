/*
 * This code is sample code, provided as-is, and we make no
 * warranties as to its correctness or suitability for
 * any purpose.
 *
 * We hope that it's useful to you.  Enjoy.
 * Copyright LearningPatterns Inc.
 */
package com.mytime;

import static org.junit.Assert.*;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.MonthDay;
import java.time.Period;
import java.time.Year;
import org.junit.Test;

public class PeriodDurationTest {

  /**
   * TASK: what is the age difference (in years and months)
   * between your parents, or any other 2 people you know?
   * 
   * RESULT:
   *  Mother: 8/26/1938
   *  Father: 3/28/1925
   *  13 years, 4 months (via calendar)
   */
  @Test
  public void testAgeDifference() {
    // DONE
    LocalDate mom = LocalDate.of(1938, 8, 26);
    LocalDate dad = LocalDate.of(1925, 3, 28);
    Period ageDiff = Period.between(dad, mom);
    
    assertEquals(13, ageDiff.getYears());
    assertEquals( 4, ageDiff.getMonths());
    assertEquals("P13Y4M29D", ageDiff.toString());
  }

  /**
   * TASK: how long is it until your next birthday (in months and days)?
   * Note: for testability, you can hardcode today's date using of(), instead of using now();
   *   that way, your assertions will still work tomorrow!
   * Note: consider using the until() method of LocalDate to determine the answer (more API exposure).
   * 
   * RESULT:
   *  Today:    2/18
   *  Birthday: 12/5
   *  9 months, 17 days (via calendar)
   */
  @Test
  public void testNextBirthday() {
    // DONE - note that we're deliberately showing off the API a little bit in this solution
    // get current year
    int currentYear = Year.now().getValue();
    
    // today (hardcoded) in current year
    LocalDate today = MonthDay.of(2, 18).atYear(currentYear);
    // birthday in current year
    LocalDate bday = MonthDay.of(12, 5).atYear(currentYear);
    
    Period timeUntilBday = today.until(bday);
    
    assertEquals(9, timeUntilBday.getMonths());
    assertEquals(17, timeUntilBday.getDays());
    assertEquals("P9M17D", timeUntilBday.toString());
  }
  
  /**
   * TASK: Halley's comet orbits the sun every 75-76 years, and was last seen from Earth in 1986.
   *  1. Model its orbit as an integral number of years, using Period or Duration as appropriate.
   *  2. Calculate the year of its next appearance on Earth.
   * Note: consider using the Year class (more API exposure).
   * 
   * RESULT:
   *  1. Period of 75 years
   *  2. 1986 (via calculator)
   */
  @Test
  public void testNextHalleysComet() {
    // DONE
    Period orbit = Period.ofYears(75);
    Year lastSeen = Year.of(1986);
    Year nextSeen = lastSeen.plus(orbit);
    
    assertEquals(Year.of(2061), nextSeen);
  }
  
  /**
   * TASK: run the test below and compare the results of these two techniques to measure execution time of a method:
   *  - System.nanoTime() before and after the call, then get the difference and convert to millis.
   *  - Instant.now() before and after the call, then get the Duration between them and convert to millis.
   * 
   * RESULT:
   *  System.nanoTime() is more precise. Read the Javadoc for this method, and then for Instant.now().
   *  See also http://stackoverflow.com/questions/20689055/java-8-instant-now-with-nanosecond-resolution.
   */
  @Test
  public void testPerformance() {
    long start1 = System.nanoTime();
    businessWork();
    long end1 = System.nanoTime();
    
    double elapsedMillis1 = (end1 - start1) / 1000000.0;
    System.out.println("Execution time (ms) via System.nanoTime(): " + elapsedMillis1);
    
    
    Instant start2 = Instant.now();
    businessWork();
    Instant end2 = Instant.now();
    
    Duration duration = Duration.between(start2, end2);
    double elapsedMillis2 = duration.toNanos() / 1000000.0;
    System.out.println("Execution time (ms) via Instant.now(): " + elapsedMillis2);
  }
  
  /**
   * OPTIONAL: scientist have found that something very special occurs in regular intervals,
   * specifically every 5 hours, 5 minutes, and 5 seconds.
   * For testing purposes, the last special event occurred on Feb 18, 2016 at 10:16:48am.
   *  1. Model this interval as a Period or Duration, as appropriate.
   *  2. Determine when the next 3 occurrences of this special event will be.
   * 
   * RESULT:
   *  1. Duration of 5 hours, 5 min, and 5 sec
   *  2. Feb 18, 2016 at 3:21:53pm
   *     Feb 18, 2016 at 8:26:58pm
   *     Feb 19, 2016 at 1:32:03am
   */
  @Test
  public void testSpecialEvent() {
    // DONE
    Duration special = Duration.ofHours(5).plusMinutes(5).plusSeconds(5);
    assertEquals("PT5H5M5S", special.toString());
    
    LocalDateTime last = LocalDateTime.of(2016, 2, 18, 10, 16, 48);
    
    LocalDateTime next1 = last.plus(special);
    LocalDateTime next2 = last.plus(special.multipliedBy(2));  // or next1.plus(special)
    LocalDateTime next3 = last.plus(special.multipliedBy(3));  // or next2.plus(special)
    
    assertEquals(LocalDateTime.of(2016, 2, 18, 15, 21, 53), next1);
    assertEquals(LocalDateTime.of(2016, 2, 18, 20, 26, 58), next2);
    assertEquals(LocalDateTime.of(2016, 2, 19,  1, 32,  3), next3);
  }
  

  /**
   * This method simulates actual business work.
   * It takes between 0 and 1500ms to complete.
   */
  public static void businessWork() {
    try { Thread.sleep((long) (Math.random() * 1500)); }
    catch (InterruptedException ignored) {}
  }
}