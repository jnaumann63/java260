package com.javatunes.personnel.client;

import com.javatunes.personnel.Employee;

public class Client {

  public static void main(String[] args) {
    Employee emp = new Employee();
    emp.work();
    emp.pay();
  }
}