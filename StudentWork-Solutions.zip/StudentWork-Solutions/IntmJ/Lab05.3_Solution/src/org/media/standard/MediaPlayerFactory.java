/*
 * This code is sample code, provided as-is, and we make no
 * warranties as to its correctness or suitability for
 * any purpose.
 *
 * We hope that it's useful to you.  Enjoy.
 * Copyright LearningPatterns Inc.
 */
package org.media.standard;

/**
 * Factory for <code>MediaPlayer</code> objects.
 * 
 * Providers should implement this interface with a concrete <code>newPlayer</code> method, 
 * returning a suitable <code>MediaPlayer</code> instance.
 * 
 * Providers should also document their factory classname for end users.
 * 
 * The actual factory to be used can be specified two ways:
 * <ul>
 *  <li>Explicitly by specifying the factory classname to {@link #newInstance(String)}</li>
 *  <li>Implicitly by specifying the factory classname as a system property: <code>org.media.standard.MediaPlayerFactory</code></li>
 * </ul>
 * 
 * @author SMO, the Standards Media Consortium.
 * @see MediaPlayer 
 * @since 1.0
 */
public interface MediaPlayerFactory {
  /**
   * System property specifying classname of factory.
   */
  public static final String FACTORY_CLASS_NAME = "org.media.standard.MediaPlayerFactory";
  
  /**
   * Creates new <code>MediaPlayer</code> instance from this factory.
   */
  public MediaPlayer newPlayer();
  
  /**
   * Instantiates factory from system property <code>org.media.standard.MediaPlayerFactory</code>.
   * @see #FACTORY_CLASS_NAME
   * @throws FactoryConfigurationException if the factory could not be instantiated.
   *  Note that this exception will wrap the underlying exception, e.g., <code>ClassNotFoundException</code>.
   */
  static public MediaPlayerFactory newInstance()
  throws FactoryConfigurationException {
    String factoryClassName = System.getProperty(FACTORY_CLASS_NAME);
    return newInstance(factoryClassName);
  }
  
  /**
   * Instantiates factory from specified classname.
   * @param factoryClassName the fully qualified classname of the factory.
   * @throws FactoryConfigurationException if the factory could not be instantiated.
   *  Note that this exception will wrap the underlying exception, e.g., <code>ClassNotFoundException</code>.
   */
  static public MediaPlayerFactory newInstance(String factoryClassName)
  throws FactoryConfigurationException {
    // return value
    MediaPlayerFactory factory = null;
    // load class, create instance of class (the factory object)
    try {
      Class<MediaPlayerFactory> factoryClass = (Class<MediaPlayerFactory>) Class.forName(factoryClassName);
      factory = factoryClass.newInstance();
    }
    catch (ClassNotFoundException e) {
      throw new FactoryConfigurationException("Unable to create factory from classname: " + factoryClassName, e);
    }
    catch (Exception e) {
      throw new FactoryConfigurationException(e);
    }
    return factory;
  }
}