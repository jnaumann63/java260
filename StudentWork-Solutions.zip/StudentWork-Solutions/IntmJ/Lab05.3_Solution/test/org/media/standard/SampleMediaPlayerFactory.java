package org.media.standard;

class SampleMediaPlayerFactory
implements MediaPlayerFactory {
  
  public MediaPlayer newPlayer() {
    return new SampleMediaPlayer();
  }
}