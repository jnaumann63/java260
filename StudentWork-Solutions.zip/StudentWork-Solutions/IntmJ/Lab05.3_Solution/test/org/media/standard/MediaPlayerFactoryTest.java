/*
 * This code is sample code, provided as-is, and we make no
 * warranties as to its correctness or suitability for
 * any purpose.
 *
 * We hope that it's useful to you.  Enjoy.
 * Copyright LearningPatterns Inc.
 */
package org.media.standard;

import static org.junit.Assert.*;
import java.util.Arrays;
import org.junit.Test;

public class MediaPlayerFactoryTest {
  private static final String SAMPLE_FACTORY_CLASS_NAME = "org.media.standard.SampleMediaPlayerFactory";
  
  @Test
  public void testFactorySpecifiedClassname() {
    MediaPlayerFactory sampleFactory = MediaPlayerFactory.newInstance(SAMPLE_FACTORY_CLASS_NAME);
    assertEquals(SampleMediaPlayerFactory.class, sampleFactory.getClass());
  }
  
  @Test
  public void testFactorySpecifiedClassnameIncorrect() {
    String badClassName = "INVALID.CLASS.NAME";
    try {
      MediaPlayerFactory.newInstance(badClassName);
      fail("FactoryConfigurationException should have been thrown, but wasn't");
    }
    catch (FactoryConfigurationException expected) {
      assertEquals("Unable to create factory from classname: " + badClassName, expected.getMessage());
      assertEquals(ClassNotFoundException.class, expected.getCause().getClass());
    }
  }
  
  @Test
  public void testFactorySystemPropertyClassname() {
    System.setProperty(MediaPlayerFactory.FACTORY_CLASS_NAME, SAMPLE_FACTORY_CLASS_NAME);
    MediaPlayerFactory sampleFactory = MediaPlayerFactory.newInstance();
    assertEquals(SampleMediaPlayerFactory.class, sampleFactory.getClass());
  }
  
  @Test
  public void testFactorySystemPropertyClassnameMissing() {
    // fail to set system property - oops - same situation as setting it incorrectly -> property value is null
    System.clearProperty(MediaPlayerFactory.FACTORY_CLASS_NAME);
    try {
      MediaPlayerFactory.newInstance();
      fail("FactoryConfigurationException should have been thrown, but wasn't");
    }
    catch (FactoryConfigurationException expected) {
      assertEquals(NullPointerException.class, expected.getCause().getClass());
    }
  }
  
  @Test
  public void testSamplePlayer() {
    MediaPlayerFactory factory = MediaPlayerFactory.newInstance(SAMPLE_FACTORY_CLASS_NAME);
    MediaPlayer player = factory.newPlayer();
    assertEquals(SampleMediaPlayer.class, player.getClass());
    assertEquals("[Sample]", Arrays.toString(player.getSupportedContentTypes()));
    assertEquals("SampleMediaPlayer playing sample media", player.play());
    System.out.println(player.play());
  }
}