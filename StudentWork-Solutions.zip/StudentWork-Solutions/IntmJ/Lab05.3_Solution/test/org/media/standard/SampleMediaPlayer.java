package org.media.standard;

class SampleMediaPlayer
implements MediaPlayer {

  public String[] getSupportedContentTypes() {
    return new String[] {"Sample"};
  }

  public String play() {
    return "SampleMediaPlayer playing sample media";
  }
}