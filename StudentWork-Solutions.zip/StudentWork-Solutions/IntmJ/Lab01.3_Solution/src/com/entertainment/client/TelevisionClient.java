/*
 * This code is sample code, provided as-is, and we make no
 * warranties as to its correctness or suitability for
 * any purpose.
 *
 * We hope that it's useful to you.  Enjoy.
 * Copyright LearningPatterns Inc.
 */
package com.entertainment.client;

import java.util.HashSet;
import java.util.Set;
import com.entertainment.Television;

public class TelevisionClient {

  public static void main(String[] args) {
    Television tvA = new Television("Sony", 50);
    Television tvB = new Television("Sony", 50);
    System.out.println(tvA);
    System.out.println(tvB);
    System.out.println("tvA == tvB: " + (tvA == tvB));
    System.out.println("tvA.equals(tvB): " + tvA.equals(tvB));
    
    // duplicates should be rejected from a Set
    Set<Television> tvs = new HashSet<Television>();
    tvs.add(tvA);
    tvs.add(tvB);
    System.out.println("Set size: " + tvs.size());
    System.out.println("Set contents: " + tvs);
  }
}