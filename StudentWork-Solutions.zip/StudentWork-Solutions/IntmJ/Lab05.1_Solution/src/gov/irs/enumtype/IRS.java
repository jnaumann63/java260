/*
 * This code is sample code, provided as-is, and we make no
 * warranties as to its correctness or suitability for
 * any purpose.
 *
 * We hope that it's useful to you.  Enjoy.
 * Copyright LearningPatterns Inc.
 */
package gov.irs.enumtype;

import gov.irs.TaxPayer;

public interface IRS {
  // BUSINESS METHODS
  public void collectTaxes();
  public void register(TaxPayer payer);
  
  // singleton retrieval method
  public static IRS getInstance() {
    return IRSEnum.getInstance();
  }
}