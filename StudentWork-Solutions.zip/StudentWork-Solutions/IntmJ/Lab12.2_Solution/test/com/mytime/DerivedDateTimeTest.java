/*
 * This code is sample code, provided as-is, and we make no
 * warranties as to its correctness or suitability for
 * any purpose.
 *
 * We hope that it's useful to you.  Enjoy.
 * Copyright LearningPatterns Inc.
 */
package com.mytime;

import static java.time.DayOfWeek.*;
import static java.time.temporal.ChronoUnit.*;
import static java.time.temporal.TemporalAdjusters.*;
import static org.junit.Assert.*;
import java.time.LocalDate;
import org.junit.Test;

public class DerivedDateTimeTest {

  /**
   * TASK: new American presidents are often measured by their performance 
   * during the first 100 days in office.
   * Inauguration Day 2017 is Jan 20.
   * When is this president's 100-day deadline?
   * 
   * RESULT: 4/30/2017 (via calendar)
   */
  @Test
  public void testPresidentsFirst100Days() {
    // DONE
    LocalDate inauguration = LocalDate.of(2017, 1, 20);
    LocalDate deadline = inauguration.plusDays(100);
    
    assertEquals(LocalDate.of(2017, 4, 30), deadline);
  }

  /**
   * TASK: Certain times of the year seem to have more birthdays than other times.
   * Some believe that this is because more babies are conceived during certain times of year.
   * Below, assume a due date 38 weeks after conception, during a non-leap-year.
   * Note: you can just use visual inspection for these (sysout).
   * 
   * RESULT: 11/7 for Valentine's Day babies and 9/24 for NYE babies
   */
  @Test
  public void testPopularBirthdays() {
    // DONE: what is the average birthday of someone conceived on Valentine's Day?
    LocalDate valentines = LocalDate.of(2015, 2, 14);
    LocalDate birthValentines = valentines.plusWeeks(38);
    System.out.println(birthValentines);
    
    // DONE: what is the average birthday of someone conceived on New Year's Eve (after midnight)?
    // Note: try using the generalized plus() method
    LocalDate nye = LocalDate.of(2015, 1, 1);
    LocalDate birthNYE = nye.plus(38, WEEKS);  // static import of ChronoUnit.*
    System.out.println(birthNYE);
  }
  
  /**
   * TASK: you've saved diligently your whole life and plan to retire as soon as
   * you can take distributions from your 401(k) penalty-free, which is when you turn 59 1/2.
   * When will / did you retire?
   * 
   * RESULT: 6/5/2026 (via calendar)
   */
  @Test
  public void testEarlyRetirement() {
    // DONE
    LocalDate bday = LocalDate.of(1966, 12, 5);
    LocalDate retirement = bday.plusYears(59).plusMonths(6);
    
    assertEquals(LocalDate.of(2026, 6, 5), retirement);
  }
  
  /**
   * TASK: when was Labor Day during the year you were born?
   * Note: start with a LocalDate equal to your birthday.
   * Note: Labor Day is the first Monday in Sept.
   * 
   * RESULT: 11/7/1966 (via calendar)
   */
  @Test
  public void testLaborDay() {
    // DONE
    LocalDate bday = LocalDate.of(1966, 12, 5);
    LocalDate laborDay = bday.withMonth(11).with(firstInMonth(MONDAY));
    
    assertEquals(LocalDate.of(1966, 11, 7), laborDay);
  }
  
  /**
   * OPTIONAL: Election Day in the United States is defined as the Tuesday immediately after the 1st Monday in November.
   * When is Election Day 2024?
   * 
   * RESULT: 11/5/2024 (via calendar)
   */
  @Test
  public void testElectionDay() {
    // DONE
    LocalDate seed = LocalDate.of(2024, 11, 1);
    // below assumes static import of TemporalAdjusters.* and DayOfWeek.*
    LocalDate electionDay = seed.with(firstInMonth(MONDAY)).with(next(TUESDAY));
    
    assertEquals(LocalDate.of(2024, 11, 5), electionDay);
  }
  
  /**
   * OPTIONAL: Akesh and Samanta were married on 6/6/1969.
   * They are planning their 50th wedding anniversary, and would like to throw a big party.
   * If their anniversary does not fall on a Saturday, they'd like to have their party the following Saturday.
   * What is the date of the party?
   * 
   * RESULT: 6/8/2019 (via calendar)
   */
  @Test
  public void testAnniversary() {
    // DONE
    LocalDate wedding = LocalDate.of(1969, 6, 6);
    LocalDate anniversary = wedding.plusYears(50);
    // below assumes static import of TemporalAdjusters.* and DayOfWeek.*
    LocalDate anniversaryParty = anniversary.with(nextOrSame(SATURDAY));
    
    assertEquals(LocalDate.of(2019, 6, 8), anniversaryParty);
  }
}