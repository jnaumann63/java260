package com.mytime.zone;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import org.junit.Test;

public class ConcertTimeTest {

  /**
   * OPTIONAL: your favorite band is playing live in Toronto, Canada on June 18, 2016, at 7pm.
   * You live in Perth, Australia, and want to watch a live simulcast via the web.
   * When is the show?
   * Note: you can use visual inspection (sysout).
   * 
   * RESULT: June 19, 2016 at 7am (visual inspection)
   */
  @Test
  public void testLiveConcert() {
    // DONE
    ZonedDateTime concertTime = ZonedDateTime.of(LocalDateTime.of(2016, 6, 18, 19, 0), ZoneId.of("Canada/Eastern"));
    ZonedDateTime perthTime = concertTime.withZoneSameInstant(ZoneId.of("Australia/Perth"));
    
    System.out.println(concertTime);
    System.out.println(perthTime);
  }
}