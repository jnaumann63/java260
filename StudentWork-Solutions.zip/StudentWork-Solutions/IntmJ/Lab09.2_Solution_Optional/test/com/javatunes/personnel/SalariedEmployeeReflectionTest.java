/*
 * This code is sample code, provided as-is, and we make no
 * warranties as to its correctness or suitability for
 * any purpose.
 *
 * We hope that it's useful to you.  Enjoy.
 * Copyright LearningPatterns Inc.
 */
package com.javatunes.personnel;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.sql.Date;
import org.junit.Before;
import org.junit.Test;

public class SalariedEmployeeReflectionTest {
  private SalariedEmployee emp;
  
  @Before
  public void init() {
    emp = new SalariedEmployee("Ron", Date.valueOf("2010-10-20"));
  }

  @Test
  public void testInvokeMethod()
  throws Exception {
    Class<?> klass = emp.getClass();
    Method setSalaryMethod = klass.getDeclaredMethod("setSalary", Double.class);  // setSalary(Double salary)
    Method toStringMethod = klass.getDeclaredMethod("toString");  // toString()
    
    setSalaryMethod.invoke(emp, 64000.0);  // emp.setSalary(64000.0)
    String toStringValue = (String) toStringMethod.invoke(emp);  // emp.toString()
    System.out.println(toStringValue);
  }
  
  @Test
  public void testSetFieldValue()
  throws Exception {
    Class<?> klass = emp.getClass();
    Field salaryField = klass.getDeclaredField("salary");  // private Double salary
    
    salaryField.setAccessible(true);  // request access to private member
    salaryField.set(emp, 32000.0);    // emp.salary = 32000.0
    System.out.println(emp);
  }
  
  @Test
  public void testNewInstanceDefault()
  throws Exception {
    Class<SalariedEmployee> klass = SalariedEmployee.class;  // .class shortcut notation -> yields type-safe Class<T>
    
    SalariedEmployee salaried = klass.newInstance();  // new SalariedEmployee()
    System.out.println(salaried);
  }
  
  @Test
  public void testNewInstanceCtor()
  throws Exception {
    Class<SalariedEmployee> klass = SalariedEmployee.class;  // .class shortcut notation -> yields type-safe Class<T>
    Constructor<SalariedEmployee> ctor = 
      klass.getConstructor(String.class, Date.class, Double.class);  // SalariedEmployee(String name, Date hireDate, Double salary)
    
    SalariedEmployee salaried = 
      ctor.newInstance("Mitch", Date.valueOf("2014-04-20"), 95000.0);  // new SalariedEmployee("Mitch", Date.valueOf("2014-04-20"), 95000.0)
    System.out.println(salaried);
  }
}