/*
 * This code is sample code, provided as-is, and we make no
 * warranties as to its correctness or suitability for
 * any purpose.
 *
 * We hope that it's useful to you.  Enjoy.
 * Copyright LearningPatterns Inc.
 */
package com.entertainment.client;

import org.apache.log4j.Logger;
import com.entertainment.ChannelDisallowedException;
import com.entertainment.InvalidChannelException;
import com.entertainment.Television;

public class TelevisionValidationTest {
  private static final Logger log = Logger.getLogger(TelevisionValidationTest.class);

  public static void main(String[] args) {
    try {
      Television tv1 = new Television("RCA");
      // tv1.setVolume(-10);  // invalid volume, exception thrown
      // tv1.changeChannel(0);     // invalid channel, exception thrown
      tv1.enableParentalControl();
      tv1.changeChannel(500);
    }
    catch (IllegalArgumentException | InvalidChannelException e) {
      log.error(e.getMessage(), e);
    }
    catch (ChannelDisallowedException e) {
      log.error("GOTCHA!", e);
    }
  }
}