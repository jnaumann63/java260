package com.entertainment.client;

import java.util.HashSet;
import java.util.Set;

import com.entertainment.*;

import static com.entertainment.DisplayType.*;
//import com.entertainment.DisplayType;
//import com.entertainment.Television;

public class TelevisionClient {
	public static void main(String[] args) {
	try {
			Television tv1 = new Television();
			Television tv2 = new Television("RCA", 2);

			System.out.println(tv1);
			System.out.println(tv2);

			System.out.println();

			tv1.changeChannel(9);
			System.out.println(tv1);

			System.out.println();

			System.out.println();

			Television tvA = new Television("Samsung", -99);
			Television tvB = new Television("Samsung", 50);
			System.out.println(tvA);
			System.out.println(tvB);
			System.out.println("tvA == tvB: " + (tvA == tvB));
			System.out.println("tvA.equals(tvB): " + tvA.equals(tvB));
//
//		Set<Television> tvs = new HashSet<Television>();
//		tvs.add(tvA);
//		tvs.add(tvB);
//
//		System.out.println();
//		System.out.println(tvs.size());
//		System.out.println(tvs);
//
//		Television tv3 = new Television("Sony", 50, com.entertainment.DisplayType.LED); // LED: static import of
//																						// DisplayType constants
//		System.out.println(tv3);
//		System.out.println();
//
//		// try out "equal" Television instances - display now included in comparison
//		Television tvX = new Television("Sony", 50, PLASMA);
//		Television tvY = new Television("Sony", 50, LCD);
//		Television tvZ = new Television("Sony", 50, PLASMA);
//		System.out.println("tvX.equals(tvY): " + tvX.equals(tvY));
//		System.out.println("tvX.equals(tvZ): " + tvX.equals(tvZ));
		} catch (InvalidChannelException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
