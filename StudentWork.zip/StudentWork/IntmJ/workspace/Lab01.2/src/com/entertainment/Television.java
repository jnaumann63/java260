package com.entertainment;

import java.util.Objects;

public class Television implements Comparable<Television> {

	public static final int MIN_VOLUME = 0;
	public static final int MAX_VOLUME = 100;
	public static final int MIN_CHANNEL = 1;
	public static final int MAX_CHANNEL = 999;

	private String brand;
	private int volume;
	private DisplayType display;
	private Tuner tuner = new Tuner();

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public int getVolume() {
		return volume;
	}

	public void setVolume(int volume) {
		if (volume >= MIN_VOLUME && volume <= MAX_VOLUME) {
			this.volume = volume;
		} else {throw new IllegalArgumentException("Invalid volume " + volume);}
	}

	public int getCurrentChannel() {
		return tuner.getChannel();
	}

	 public void changeChannel(int channel) throws InvalidChannelException {
		    if (channel >= MIN_CHANNEL && channel <= MAX_CHANNEL) {
		      tuner.setChannel(channel);  // delegate to contained Tuner object
		    }else {
				throw new InvalidChannelException("Invalid channel " + channel);
			}
		  }

	
	
	// public void changeChannel(int channel) {
	// tuner.setChannel(channel);
	// }

	public DisplayType getDisplay() {
		return this.display;
	}

	public void setDisplay(DisplayType display) {
		this.display = display;
	}

	public Television() {
	}

	public Television(String brand, int volume) {
		setBrand(brand);
		setVolume(volume);
	}

	public Television(String brand, int volume, DisplayType display) {
		// setBrand(brand);
		// setVolume(volume);
		this(brand, volume);
		setDisplay(display);
	}

	public String toString() {
		return getClass().getSimpleName() + " [brand=" + getBrand() + ", volume=" + getVolume() + ", currentChannel="
				+ getCurrentChannel() + ", display=" + getDisplay() + "]";
	}

	public int compareTo(Television other) {
		return this.getBrand().compareTo(other.getBrand());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		// final int prime = 31;
		// int result = 1;
		// result = prime * result + ((brand == null) ? 0 : brand.hashCode());
		// result = prime * result + volume;
		// return result;
		return Objects.hash(getBrand(), getVolume());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		boolean result = false;
		if (obj instanceof Television) {
			Television other = (Television) obj;
			result = Objects.equals(this.getBrand(), other.getBrand())
					&& Objects.equals(this.getVolume(), other.getVolume())
					&& Objects.equals(this.getDisplay(), other.getDisplay());

		}
		return result;
		// if (this == obj)
		// return true;
		// if (obj == null)
		// return false;
		// if (getClass() != obj.getClass())
		// return false;
		// Television other = (Television) obj;
		// if (brand == null) {
		// if (other.brand != null)
		// return false;
		// } else if (!brand.equals(other.brand))
		// return false;
		// if (volume != other.volume)
		// return false;
		// return true;
	}

}
