package com.entertainment;

public enum DisplayType { LCD, LED, OLED, PLASMA, CRT

}
