package com.javatunes.accounting;

import com.javatunes.personnel.Employee;

public interface PayCalculator {
  public double amount();
}