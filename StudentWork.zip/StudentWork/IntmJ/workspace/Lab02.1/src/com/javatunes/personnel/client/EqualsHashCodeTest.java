package com.javatunes.personnel.client;

import java.sql.Date;
import com.javatunes.personnel.HourlyEmployee;
import com.javatunes.personnel.SalariedEmployee;

public class EqualsHashCodeTest {
  
  public static void main(String[] args) {
    SalariedEmployee semp1 = new SalariedEmployee("Lauren", Date.valueOf("1997-04-08"), 50000.0);
    SalariedEmployee semp2 = new SalariedEmployee("Lauren", Date.valueOf("1997-04-08"), 50000.0);
    System.out.println("equals: " + semp1.equals(semp2));
    System.out.println("semp1 hashcode: " + semp1.hashCode());
    System.out.println("semp2 hashcode: " + semp2.hashCode());
    System.out.println();
    
    HourlyEmployee hemp1 = new HourlyEmployee("Lonnie",   Date.valueOf("2015-03-31"), 35.0, 40.0);
    HourlyEmployee hemp2 = new HourlyEmployee("Lonnie",   Date.valueOf("2015-03-31"), 35.0, 40.0);
    System.out.println("equals: " + hemp1.equals(hemp2));
    System.out.println("hemp1 hashcode: " + hemp1.hashCode());
    System.out.println("hemp2 hashcode: " + hemp2.hashCode());
  }
}