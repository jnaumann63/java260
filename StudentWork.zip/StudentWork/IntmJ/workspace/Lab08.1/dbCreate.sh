# TODO: uncomment the line below appropriate for your IDE

# Eclipse
# java -classpath bin:lib/derby.jar:lib/derbytools.jar com.javatunes.db.internal.EmbeddedDerby create

# IntelliJ
# java -classpath ../out/production/Lab08.1:lib/derby.jar:lib/derbytools.jar com.javatunes.db.internal.EmbeddedDerby create