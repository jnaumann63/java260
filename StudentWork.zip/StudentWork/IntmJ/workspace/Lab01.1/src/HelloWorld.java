
public class HelloWorld 
{

	public static void main(String[] args) {
		Integer age = 55;
		String strAge = age.toString();
		System.out.println("Hello World");
		
		System.out.println(strAge);
		System.out.println(age.toString());
		
	}

}
