# TODO: change this to match your environment
M2_HOME=/StudentWork/IntmJ/Software/maven

$M2_HOME/bin/mvn $*