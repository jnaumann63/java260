# TODO: change this to match your environment
ANT_HOME=/StudentWork/IntmJ/Software/ant

$ANT_HOME/bin/ant $*