package com.mytime.zone;

import org.junit.Test;

public class ConcertTimeTest {

  /**
   * OPTIONAL: your favorite band is playing live in Toronto, Canada on June 18, 2016, at 7pm.
   * You live in Perth, Australia, and want to watch a live simulcast via the web.
   * When is the show?
   * Note: you can use visual inspection (sysout).
   * 
   * RESULT: 
   */
  @Test
  public void testLiveConcert() {
    // TODO
  }
}